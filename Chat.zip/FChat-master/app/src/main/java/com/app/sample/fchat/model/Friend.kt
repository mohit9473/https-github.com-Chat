package com.app.sample.fchat.model

import java.io.Serializable

class Friend(val id: String, val name: String, val photo: String) : Serializable
